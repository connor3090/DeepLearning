import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt

x = torch.rand(5, 3)
print(x)